package com.example.jamsstore;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;

import androidx.fragment.app.Fragment;

public class FragmentUno extends Fragment {
    private View fragmento;

    public FragmentUno() {

    }
    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState){

       fragmento = inflater.inflate(R.layout.fragment_uno, container,false);

        return fragmento;
    }
}
